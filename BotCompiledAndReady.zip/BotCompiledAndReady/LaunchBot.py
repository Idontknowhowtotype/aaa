import os
import discord
import getpass
from discord.ext import commands
from discord import app_commands
from dotenv import load_dotenv

def load_art():
    with open("art.txt", "r", encoding="utf-8") as f:
        return f.read()

def load_second_art():
    with open("art2.txt", "r", encoding="utf-8") as f:
        return f.read()

art = load_art()
errorart = load_second_art()

print(art)

choice = input("Enter 1 to input token manually, or 2 to use token from .env: ").strip()
if choice == "1":
    DISCORD_TOKEN = getpass.getpass("Enter bot token: ")
    if not DISCORD_TOKEN:
        raise ValueError("Bot token is required!")
elif choice == "2":
    load_dotenv()
    DISCORD_TOKEN = os.getenv('DISCORD_TOKEN')
    if DISCORD_TOKEN is None:
        raise ValueError("DISCORD_TOKEN not found in environment variables.")
else:
    raise ValueError("Invalid choice! Please enter 1 or 2.")

intents = discord.Intents.default()
intents.messages = True
intents.guilds = True
intents.message_content = True

class RegisteredUser:
    def __init__(self, username, password, email):
        self.username = username
        self.password = password
        self.email = email
    def display_user_info(self):
        print(f"User data: {self.__dict__}")
        print("Request accepted. Awaiting for another request.")
    def display_user_info2(self):
        print(f"User data: {self.__dict__}")
        print("Request denied. Awaiting for another request.")

UserDatabase = {}

class MyBot(commands.Bot):
    def __init__(self):
        super().__init__(command_prefix="!", intents=intents)
    async def setup_hook(self):
        await self.tree.sync()

bot = MyBot()

@bot.tree.command(name="register", description="Register a new user")
@app_commands.describe(
    username="Username for registration",
    email="Email address",
    password="Password"
)
async def register_slash(interaction: discord.Interaction, username: str, email: str, password: str):
    print(f"Request from {interaction.user.name} to register user: {username}")
    if username in UserDatabase:
        temp_user = RegisteredUser(username, password, email)
        temp_user.display_user_info2()
        await interaction.response.send_message(f"User {username} already exists.", ephemeral=True)
    else:
        UserDatabase[username] = RegisteredUser(username, password, email)
        UserDatabase[username].display_user_info()
        await interaction.response.send_message(f"User {username} registered!", ephemeral=True)

@bot.tree.command(name="login", description="Login as a user")
@app_commands.describe(
    username="Your username",
    password="Your password"
)
async def login_slash(interaction: discord.Interaction, username: str, password: str):
    print(f"Request from {interaction.user.name} to login as: {username}")
    temp_user = RegisteredUser(username, password, email="N/A")
    print(f"User data: {temp_user.__dict__}")
    user = UserDatabase.get(username)
    if user and user.password == password:
        print("Request accepted. Awaiting for another request.")
        user.display_user_info()
        await interaction.response.send_message(f"Logged in! Welcome, {username}.", ephemeral=True)
    else:
        print("Request denied. Awaiting for another request.")
        await interaction.response.send_message("Wrong username or password.", ephemeral=True)

@bot.tree.command(name="delete_user", description="Delete a user (admin only)")
@app_commands.describe(
    username="Username to delete"
)
async def delete_user_slash(interaction: discord.Interaction, username: str):
    if interaction.user.id != 1333905734970245313:
        await interaction.response.send_message("You do not have permission to delete users.", ephemeral=True)
        return
    print(f"Request from {interaction.user.name} to delete user: {username}")
    if username in UserDatabase:
        UserDatabase[username].display_user_info()
        print("Request accepted. Awaiting for another request.")
        del UserDatabase[username]
        await interaction.response.send_message(f"User {username} removed from DB.", ephemeral=True)
    else:
        temp_user = RegisteredUser(username, password="N/A", email="N/A")
        print(f"User data: {temp_user.__dict__}")
        print("Request denied. Awaiting for another request.")
        await interaction.response.send_message(f"User {username} not found.", ephemeral=True)

@bot.tree.command(name="logout", description="Logout a user")
@app_commands.describe(
    username="Username to logout"
)
async def logout_slash(interaction: discord.Interaction, username: str):
    print(f"Request from {interaction.user.name} to logout user: {username}")
    temp_user = RegisteredUser(username, password="N/A", email="N/A")
    print(f"User data: {temp_user.__dict__}")
    if username in UserDatabase:
        print("Request accepted. Awaiting for another request.")
        UserDatabase[username].display_user_info()
        await interaction.response.send_message(f"User {username} logged out.", ephemeral=True)
    else:
        print("Request denied. Awaiting for another request.")
        await interaction.response.send_message(f"User {username} not found.", ephemeral=True)

@bot.tree.command(name="users", description="Show all registered users")
async def users_slash(interaction: discord.Interaction):
    print(f"Request from {interaction.user.name} to view all users.")
    if not UserDatabase:
        print("Request denied. Awaiting for another request.")
        await interaction.response.send_message("DB is empty.", ephemeral=True)
    else:
        print("Request accepted. Awaiting for another request.")
        users_list = "\n".join([f"{u.username} ({u.email})" for u in UserDatabase.values()])
        await interaction.response.send_message(f"Users:\n{users_list}", ephemeral=True)

@bot.tree.command(name="status", description="Show bot status")
async def status_slash(interaction: discord.Interaction):
    print(f"Request from {interaction.user.name} to view bot status.")
    print("Request accepted. Awaiting for another request.")
    await interaction.response.send_message("Bot is running 🟢", ephemeral=True)

@bot.event
async def on_ready():
    print(f'Logged in as {bot.user.name} - {bot.user.id}')
    print(f'Servers: {len(bot.guilds)}')
    print('------')

@bot.event
async def on_error(event, *args, **kwargs):
    print(errorart)
    print("An error occurred in event:", event)

bot.run(DISCORD_TOKEN)